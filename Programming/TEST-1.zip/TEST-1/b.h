#define b_def

//File Content