#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#define min(a,b) a <= b ? a : b
#define max(a,b) a >= b ? a : b

double** sum(double** a, double** b) {  //a[0] - значения, a[1] - скачки
    
}

int main() {
    

    return EXIT_SUCCESS;
}